import os

__version__ = '0.1.6'

os.environ['KERAS_BACKEND'] = 'theano'
