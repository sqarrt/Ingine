import os

os.environ['KERAS_BACKEND'] = 'theano'