import os

__version__ = '0.1.21a'

os.environ['KERAS_BACKEND'] = 'theano'
