import os

__version__ = '0.1.5'

os.environ['KERAS_BACKEND'] = 'theano'
