import os

__version__ = '0.1.1a'

os.environ['KERAS_BACKEND'] = 'theano'
