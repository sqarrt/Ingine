import os

__version__ = '0.1.2a'

os.environ['KERAS_BACKEND'] = 'theano'
