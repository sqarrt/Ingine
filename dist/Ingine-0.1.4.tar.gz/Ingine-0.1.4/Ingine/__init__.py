import os

__version__ = '0.1.4'

os.environ['KERAS_BACKEND'] = 'theano'
